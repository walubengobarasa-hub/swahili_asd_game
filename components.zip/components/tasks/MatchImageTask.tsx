import React, { useMemo, useState } from "react";
import { Image, Pressable, Text, View } from "react-native";

type Props = { task: any; onAnswer: (answer: string) => void; locked?: boolean };

export default function MatchImageTask({ task, onAnswer, locked }: Props) {
  const options = useMemo(() => task.options ?? [], [task]);
  const [selected, setSelected] = useState<number | null>(null);

  return (
    <View style={{ gap: 12 }}>
      <Text style={{ color: "#e5e7eb", fontSize: 16, fontWeight: "700" }}>{task.prompt_sw}</Text>

      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
        {options.map((opt: any) => {
          const isSel = selected === opt.lexicon_id;
          return (
            <Pressable
              key={String(opt.lexicon_id)}
              disabled={locked}
              onPress={() => {
                setSelected(opt.lexicon_id);
                onAnswer(String(opt.lexicon_id));
              }}
              style={({ pressed }) => [
                {
                  width: "48%",
                  borderRadius: 16,
                  borderWidth: 1,
                  borderColor: isSel ? "rgba(124,58,237,1)" : "rgba(255,255,255,0.12)",
                  backgroundColor: "rgba(255,255,255,0.05)",
                  padding: 10,
                  opacity: pressed ? 0.9 : 1,
                },
              ]}
            >
              {opt.image_url ? (
                <Image
                  source={{ uri: opt.image_url }}
                  style={{ width: "100%", height: 140, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.06)" }}
                  resizeMode="cover"
                />
              ) : (
                <View style={{ height: 140, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.06)" }} />
              )}
              <Text style={{ marginTop: 8, color: "#e5e7eb", fontWeight: "700" }}>{opt.label_sw}</Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}
