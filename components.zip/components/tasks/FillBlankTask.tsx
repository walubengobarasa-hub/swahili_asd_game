import React, { useMemo, useState } from "react";
import { Pressable, Text, View } from "react-native";

type Props = { task: any; onAnswer: (answer: string) => void; locked?: boolean };

export default function FillBlankTask({ task, onAnswer, locked }: Props) {
  const options = useMemo(() => task.options ?? [], [task]);
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <View style={{ gap: 12 }}>
      <Text style={{ color: "#e5e7eb", fontSize: 16, fontWeight: "700" }}>{task.prompt_sw}</Text>
      {!!task.hint_sw && <Text style={{ color: "rgba(229,231,235,0.75)" }}>{task.hint_sw}</Text>}

      <View style={{ gap: 10 }}>
        {options.map((opt: string) => {
          const isSel = selected === opt;
          return (
            <Pressable
              key={opt}
              disabled={locked}
              onPress={() => {
                setSelected(opt);
                onAnswer(String(opt));
              }}
              style={({ pressed }) => [
                {
                  paddingVertical: 12,
                  paddingHorizontal: 12,
                  borderRadius: 14,
                  borderWidth: 1,
                  borderColor: isSel ? "rgba(124,58,237,1)" : "rgba(255,255,255,0.12)",
                  backgroundColor: "rgba(255,255,255,0.05)",
                  opacity: pressed ? 0.9 : 1,
                },
              ]}
            >
              <Text style={{ color: "#e5e7eb", fontWeight: "700", fontSize: 16 }}>{opt}</Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}
