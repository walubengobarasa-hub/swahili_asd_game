import React from "react";
import { Text, View } from "react-native";
import { FillBlankTask } from "./FillBlankTask";
import { MatchImageTask } from "./MatchImageTask";
import { MatchWordTask } from "./MatchWordTask";
import { SentenceBuilderTask } from "./SentenceBuilderTask";

type Props = {
  task: any;
  onAnswer: (answer: string) => void;
  locked?: boolean;
};

export default function TaskRenderer({ task, onAnswer, locked }: Props) {
  if (!task) return null;

  const type = task.task_type;

  switch (type) {
    case "match_image":
      return <MatchImageTask task={task} onAnswer={onAnswer} locked={locked} />;
    case "match_word":
      return <MatchWordTask task={task} onAnswer={onAnswer} locked={locked} />;
    case "fill_blank":
      return <FillBlankTask task={task} onAnswer={onAnswer} locked={locked} />;
    case "sentence_builder":
      return <SentenceBuilderTask task={task} onAnswer={onAnswer} locked={locked} />;
    default:
      return (
        <View>
          <Text style={{ color: "#fca5a5", fontWeight: "700" }}>
            Unsupported task type: {String(type)}
          </Text>
        </View>
      );
  }
}
