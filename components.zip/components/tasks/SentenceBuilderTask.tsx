import React, { useMemo, useState } from "react";
import { Pressable, Text, View } from "react-native";

type Props = { task: any; onAnswer: (answer: string) => void; locked?: boolean };

export default function SentenceBuilderTask({ task, onAnswer, locked }: Props) {
  const tiles = useMemo(() => task.tiles ?? [], [task]);
  const [picked, setPicked] = useState<string[]>([]);

  const submit = (nextPicked: string[]) => {
    onAnswer(JSON.stringify(nextPicked));
  };

  const addTile = (t: string) => {
    const next = [...picked, t];
    setPicked(next);
    if ((task.slots?.length ?? 0) > 0 && next.length === task.slots.length) submit(next);
  };

  const reset = () => {
    setPicked([]);
    submit([]);
  };

  return (
    <View style={{ gap: 12 }}>
      <Text style={{ color: "#e5e7eb", fontSize: 16, fontWeight: "700" }}>{task.prompt_sw}</Text>

      <View
        style={{
          padding: 12,
          borderRadius: 14,
          backgroundColor: "rgba(255,255,255,0.05)",
          borderWidth: 1,
          borderColor: "rgba(255,255,255,0.10)",
          minHeight: 56,
          justifyContent: "center",
        }}
      >
        <Text style={{ color: "#e5e7eb", fontWeight: "700" }}>
          {picked.length ? picked.join(" ") : "—"}
        </Text>
      </View>

      <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
        {tiles.map((tile: any, idx: number) => (
          <Pressable
            key={idx}
            disabled={locked}
            onPress={() => addTile(tile.text)}
            style={({ pressed }) => [
              {
                paddingVertical: 10,
                paddingHorizontal: 12,
                borderRadius: 999,
                borderWidth: 1,
                borderColor: "rgba(255,255,255,0.12)",
                backgroundColor: "rgba(255,255,255,0.05)",
                opacity: pressed ? 0.9 : 1,
              },
            ]}
          >
            <Text style={{ color: "#e5e7eb", fontWeight: "700" }}>{tile.text}</Text>
          </Pressable>
        ))}
      </View>

      <Pressable
        disabled={locked}
        onPress={reset}
        style={{
          alignSelf: "flex-start",
          paddingVertical: 8,
          paddingHorizontal: 10,
          borderRadius: 12,
          backgroundColor: "rgba(255,255,255,0.06)",
          borderWidth: 1,
          borderColor: "rgba(255,255,255,0.10)",
        }}
      >
        <Text style={{ color: "#e5e7eb" }}>Reset</Text>
      </Pressable>
    </View>
  );
}
