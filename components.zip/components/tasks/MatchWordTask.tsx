import React, { useMemo, useState } from "react";
import { Image, Pressable, Text, View } from "react-native";

type Props = { task: any; onAnswer: (answer: string) => void; locked?: boolean };

export default function MatchWordTask({ task, onAnswer, locked }: Props) {
  const options = useMemo(() => task.options ?? [], [task]);
  const [selected, setSelected] = useState<number | null>(null);

  return (
    <View style={{ gap: 12 }}>
      <Text style={{ color: "#e5e7eb", fontSize: 16, fontWeight: "700" }}>{task.prompt_sw}</Text>

      {!!task.prompt_image_url && (
        <Image
          source={{ uri: task.prompt_image_url }}
          style={{ width: "100%", height: 180, borderRadius: 16, backgroundColor: "rgba(255,255,255,0.06)" }}
          resizeMode="cover"
        />
      )}

      <View style={{ gap: 10 }}>
        {options.map((opt: any) => {
          const isSel = selected === opt.lexicon_id;
          return (
            <Pressable
              key={String(opt.lexicon_id)}
              disabled={locked}
              onPress={() => {
                setSelected(opt.lexicon_id);
                onAnswer(String(opt.lexicon_id));
              }}
              style={({ pressed }) => [
                {
                  paddingVertical: 12,
                  paddingHorizontal: 12,
                  borderRadius: 14,
                  borderWidth: 1,
                  borderColor: isSel ? "rgba(124,58,237,1)" : "rgba(255,255,255,0.12)",
                  backgroundColor: "rgba(255,255,255,0.05)",
                  opacity: pressed ? 0.9 : 1,
                },
              ]}
            >
              <Text style={{ color: "#e5e7eb", fontWeight: "700", fontSize: 16 }}>{opt.label_sw}</Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}
