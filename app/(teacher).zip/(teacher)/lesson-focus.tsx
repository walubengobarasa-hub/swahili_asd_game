import { router } from "expo-router";
import React from "react";
import { Text } from "react-native";
import GlassCard from "../../components/GlassCard";
import ResponsiveScreen from "../../components/ResponsiveScreen";
import TopBar from "../../components/TopBar";

export default function LessonFocus() {
  return (
    <ResponsiveScreen>
      <TopBar title="Lesson Focus" rightIcon="←" onRight={() => router.back()} />
      <GlassCard>
        <Text style={{ fontWeight: "800" }}>
          Coming next: teacher selects topic + difficulty + assigns to child/class.
        </Text>
      </GlassCard>
    </ResponsiveScreen>
  );
}
