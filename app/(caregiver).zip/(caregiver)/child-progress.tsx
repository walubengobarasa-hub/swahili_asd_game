import { Stack, useLocalSearchParams } from "expo-router";
import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import GlassCard from "../../components/GlassCard";
import { api } from "../../lib/api";

export default function ChildProgress() {
  const params = useLocalSearchParams<{ childId?: string }>();
  const childId = Number(params.childId ?? 1);

  const [loading, setLoading] = useState(true);
  const [report, setReport] = useState<any>(null);
  const [err, setErr] = useState<string | null>(null);

  const accuracyPct = useMemo(() => Math.round(((report?.accuracy ?? 0) as number) * 100), [report]);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setErr(null);
    api
      .getChildReport(childId)
      .then((r) => alive && setReport(r))
      .catch((e: any) => alive && setErr(e?.message ?? "Failed to load report"))
      .finally(() => alive && setLoading(false));
    return () => {
      alive = false;
    };
  }, [childId]);

  return (
    <ScrollView style={{ flex: 1, backgroundColor: "#0b1020" }} contentContainerStyle={{ padding: 16, gap: 12 }}>
      <Stack.Screen options={{ title: `Progress • Child ${childId}` }} />

      <GlassCard>
        <Text style={{ color: "#e5e7eb", fontSize: 18, fontWeight: "800" }}>Progress Snapshot</Text>

        {loading ? (
          <View style={{ paddingTop: 14 }}>
            <ActivityIndicator />
          </View>
        ) : err ? (
          <Text style={{ color: "#fca5a5", marginTop: 10 }}>{err}</Text>
        ) : (
          <>
            <Text style={{ color: "rgba(229,231,235,0.75)", marginTop: 8 }}>
              Total attempts: <Text style={{ color: "#e5e7eb", fontWeight: "800" }}>{report.total_attempts}</Text>
              {"  "}Correct: <Text style={{ color: "#e5e7eb", fontWeight: "800" }}>{report.correct}</Text>
            </Text>

            <View style={{ marginTop: 12 }}>
              <Text style={{ color: "#e5e7eb", fontWeight: "700" }}>Accuracy</Text>
              <View
                style={{
                  marginTop: 8,
                  height: 14,
                  borderRadius: 999,
                  backgroundColor: "rgba(255,255,255,0.10)",
                  overflow: "hidden",
                }}
              >
                <View style={{ width: `${accuracyPct}%`, height: "100%", backgroundColor: "rgba(124,58,237,0.95)" }} />
              </View>
              <Text style={{ color: "rgba(229,231,235,0.8)", marginTop: 6 }}>{accuracyPct}%</Text>
            </View>
          </>
        )}
      </GlassCard>

      <GlassCard>
        <Text style={{ color: "#e5e7eb", fontWeight: "800", fontSize: 16 }}>Next</Text>
        <Text style={{ color: "rgba(229,231,235,0.75)", marginTop: 6 }}>
          To show real “history”, expose attempts endpoint (latest N attempts) and mastery per lexicon_id.
        </Text>
      </GlassCard>
    </ScrollView>
  );
}
