import { Stack, useRouter } from "expo-router";
import React, { useState } from "react";
import { ScrollView, Text, TextInput, View } from "react-native";
import GlassCard from "../../components/GlassCard";
import PrimaryButton from "../../components/PrimaryButton";

export default function CaregiverHome() {
  const router = useRouter();
  const [childId, setChildId] = useState("1");

  return (
    <ScrollView style={{ flex: 1, backgroundColor: "#0b1020" }} contentContainerStyle={{ padding: 16, gap: 12 }}>
      <Stack.Screen options={{ title: "Caregiver" }} />

      <GlassCard>
        <Text style={{ color: "#e5e7eb", fontSize: 18, fontWeight: "800" }}>Caregiver Dashboard</Text>
        <Text style={{ color: "rgba(229,231,235,0.75)", marginTop: 6 }}>
          Enter the Child ID you want to track (replace this later with a real child-list endpoint).
        </Text>

        <View style={{ marginTop: 12, gap: 8 }}>
          <Text style={{ color: "#e5e7eb", fontWeight: "700" }}>Child ID</Text>
          <TextInput
            value={childId}
            onChangeText={setChildId}
            keyboardType="number-pad"
            placeholder="e.g. 1"
            placeholderTextColor="rgba(229,231,235,0.45)"
            style={{
              paddingVertical: 12,
              paddingHorizontal: 12,
              borderRadius: 14,
              borderWidth: 1,
              borderColor: "rgba(255,255,255,0.12)",
              color: "#e5e7eb",
            }}
          />
          <PrimaryButton
            title="Open Progress"
            onPress={() => router.push({ pathname: "/(caregiver)/child-progress", params: { childId } })}
          />
        </View>
      </GlassCard>

      <GlassCard>
        <Text style={{ color: "#e5e7eb", fontWeight: "800", fontSize: 16 }}>Quick Links</Text>
        <View style={{ height: 10 }} />
        <PrimaryButton title="Activity History" onPress={() => router.push("/(caregiver)/activity-history")} />
        <View style={{ height: 10 }} />
        <PrimaryButton title="Preferences (session + sound)" onPress={() => router.push("/(caregiver)/preferences")} />
      </GlassCard>
    </ScrollView>
  );
}
