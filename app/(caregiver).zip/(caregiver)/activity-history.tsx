import { Stack } from "expo-router";
import React from "react";
import { ScrollView, Text } from "react-native";
import GlassCard from "../../components/GlassCard";

export default function ActivityHistory() {
  return (
    <ScrollView style={{ flex: 1, backgroundColor: "#0b1020" }} contentContainerStyle={{ padding: 16, gap: 12 }}>
      <Stack.Screen options={{ title: "Activity History" }} />

      <GlassCard>
        <Text style={{ color: "#e5e7eb", fontSize: 18, fontWeight: "800" }}>History</Text>
        <Text style={{ color: "rgba(229,231,235,0.75)", marginTop: 8 }}>
          Current API only exposes overall accuracy. Add: GET /reports/child/{`{child_id}`}/attempts (latest 100) for a real list.
        </Text>
      </GlassCard>
    </ScrollView>
  );
}
