import { router } from "expo-router";
import React from "react";
import BigGreenButton from "../../components/BigGreenButton";
import GlassCard from "../../components/GlassCard";
import ResponsiveScreen from "../../components/ResponsiveScreen";
import TopBar from "../../components/TopBar";

export default function TeacherHome() {
  return (
    <ResponsiveScreen>
      <TopBar title="Teacher" rightIcon="⚙️" onRight={() => router.push("/(teacher)/lesson-focus")} />
      <GlassCard>
        <BigGreenButton label="Set Lesson Focus" onPress={() => router.push("/(teacher)/lesson-focus")} />
        <BigGreenButton label="Upload Words" onPress={() => router.push("/(teacher)/upload-words")} />
      </GlassCard>
    </ResponsiveScreen>
  );
}
